# Start Here: GitHub Setup for Vadim Koenen

Recommended GitHub username: `vadim-koenen`

The exact `vadimkoenen` username appears to already exist on GitHub, so this package assumes the cleaner available-style username `vadim-koenen`. If GitHub tells you that username is unavailable during signup, use one of these instead and replace the URLs in the files:

- `vadimkoenen-mba`
- `vadimkoenen-marketing`
- `vadimkoenenrevops`

## What is included

### 01-profile-readme-repo-vadim-koenen

Use this folder for your GitHub profile README repository. If your GitHub username is `vadim-koenen`, create a public repository named exactly:

```text
vadim-koenen
```

Upload the `README.md` file from this folder.

### 02-github-pages-repo-vadim-koenen.github.io

Use this folder for your GitHub Pages site. If your GitHub username is `vadim-koenen`, create a public repository named exactly:

```text
vadim-koenen.github.io
```

Upload all files from this folder to the repository root.

## After publishing

Your GitHub profile should be:

```text
https://github.com/vadim-koenen
```

Your GitHub Pages site should be:

```text
https://vadim-koenen.github.io/
```

Add both URLs to `vadimkoenen.com` and request indexing in Google Search Console when available.
