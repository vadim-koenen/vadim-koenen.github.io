# Vadim Koenen, MBA

Senior Marketing Automation & RevOps Leader focused on scalable B2B GTM systems, Marketo architecture, Salesforce alignment, 6sense ABM, lifecycle marketing, campaign operations, and demand generation infrastructure.

## Professional Focus

I help B2B teams turn complex marketing technology stacks into cleaner, more scalable revenue systems. My work combines strategy, hands-on campaign execution, QA discipline, lifecycle logic, and revenue operations alignment.

## Core Areas

- Marketo program architecture, QA, governance, and optimization
- Salesforce campaign alignment, lifecycle logic, and routing support
- 6sense ABM segmentation, intent-based campaign planning, and account targeting
- Lead scoring, lead routing, nurture strategy, and data quality improvement
- Salesloft and CRM-connected GTM workflows
- Campaign operations documentation, reporting readiness, and attribution structure
- Cross-functional collaboration across marketing, sales, RevOps, and IT

## Work Themes

- Marketing automation operating models
- B2B nurture and lifecycle campaign design
- ABM campaign planning and execution
- GTM systems cleanup and governance
- Campaign QA and performance readiness
- Revenue technology optimization

## Featured Site

Portfolio: https://vadimkoenen.com

GitHub Pages profile site: https://vadim-koenen.github.io

## Background

Vadim Koenen, MBA brings 12+ years of marketing automation, RevOps, demand generation, and campaign operations experience across enterprise and growth-stage B2B environments.
